"""
@author: Gabriele Girelli
@contact: gigi.ga90@gmail.com
"""


def test_placeholder():
    """Test the scripts here!"""
